CREATE DATABASE IF NOT EXISTS parts_db;
USE parts_db;

CREATE TABLE IF NOT EXISTS PART (
    sku VARCHAR(100) PRIMARY KEY,
    description TEXT,
    scooter VARCHAR(100),
    model VARCHAR(100),
    quantity INT DEFAULT 0,
    status ENUM('In Stock', 'Out of Stock') DEFAULT 'In Stock',
    photo_path VARCHAR(255) DEFAULT NULL
);

CREATE TABLE IF NOT EXISTS HT_JOBS (
    job_number VARCHAR(100) PRIMARY KEY,
    Client_name VARCHAR(255) NOT NULL,
    status ENUM('open', 'awaiting parts', 'completed') DEFAULT 'open'
);

CREATE TABLE IF NOT EXISTS PART_LIST (
    id_request INT AUTO_INCREMENT PRIMARY KEY,
    date_request DATETIME DEFAULT CURRENT_TIMESTAMP,
    job_number VARCHAR(100),
    sku VARCHAR(100),
    quantity INT DEFAULT 1,
    status ENUM('requested', 'received', 'warehouse', 'in_transit', 'customer_provided') DEFAULT 'requested',
    FOREIGN KEY (job_number) REFERENCES HT_JOBS(job_number) ON DELETE CASCADE,
    FOREIGN KEY (sku) REFERENCES PART(sku) ON DELETE CASCADE
);
